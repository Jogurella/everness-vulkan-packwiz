package dev.vitrail.mixin.game;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.vulkan.glsl.IntermediaryShaderModule;
import dev.vitrail.render.ComputeShader;
import dev.vitrail.render.SamplerReach;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.nio.ByteBuffer;

/**
 * Lists SPIR-V storage images and storage buffers beside the resources the game asks SPIRV-Cross
 * for, drops the sampled images the entry point never reaches, and lets a 3D image through
 * {@code rebind}.
 * <p>
 * Type 6 is a storage image. Type 2 is a storage buffer. Type 7 is a sampled image.
 * {@code createFromSpirv} walks 1 and 7 and leaves 2 and 6 on the bindings shaderc assigned.
 * Complementary's {@code uimage3D voxel_img} and {@code blockDataBuffer} are those resources.
 * Construction of the package-private records is {@link ComputeShader}, by reflection.
 */
@Mixin(IntermediaryShaderModule.class)
public abstract class IntermediaryShaderModuleMixin {

	/**
	 * The narrowing goes first and the two appends after, though the order does not decide the
	 * result: what {@link SamplerReach} drops is named by the reflection as a sampled image, and a
	 * storage image the appends put in the same list never was one. Read in that order all the
	 * same, because that is the order the list is meant to be understood in, the module's own
	 * resources and then what this engine adds to them.
	 */
	@Inject(method = "createFromSpirv", at = @At("RETURN"), require = 1)
	private static void vitrail$storageImages(String filename, ByteBuffer spirv,
			CallbackInfoReturnable<IntermediaryShaderModule> callback) {
		SamplerReach.narrow(filename, callback.getReturnValue());
		ComputeShader.appendStorageImages(callback.getReturnValue());
		ComputeShader.appendStorageBuffers(callback.getReturnValue());
	}

	/** The same reading as {@code GlslCompilerMixin}'s: a one or three dimensional image as two. */
	@WrapOperation(method = "rebind", require = 1,
			at = @At(value = "INVOKE",
					target = "Lcom/mojang/blaze3d/vulkan/glsl/SpvSampler;dimensions()I"))
	private int vitrail$allowLineAndVolume(@Coerce Object sampler, Operation<Integer> original) {
		int dimension = original.call(sampler);
		return dimension == 0 || dimension == 2 ? 1 : dimension;
	}
}
