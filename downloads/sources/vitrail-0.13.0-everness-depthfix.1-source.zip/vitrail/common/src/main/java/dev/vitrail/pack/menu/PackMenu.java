package dev.vitrail.pack.menu;

import dev.vitrail.pack.option.OptionIndex;
import dev.vitrail.pack.option.OptionValue;
import dev.vitrail.pack.option.PackOption;
import dev.vitrail.pack.source.PackLang;
import dev.vitrail.pack.source.ShaderProperties;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Every page a pack lays out, built once when the pack is read, in between twenty five and
 * eighty eight milliseconds on the corpus.
 * <p>
 * A token naming nothing leaves a blank and a line in {@link #warnings()} rather than throwing:
 * four of the corpus's three thousand slots name an option their own pack does not declare, and
 * a pack that ships one broken name is still a working pack.
 * <p>
 * Nothing here touches Minecraft and nothing here logs, which is what lets the whole model be
 * checked against the eight packs in ten seconds instead of a game session.
 */
public final class PackMenu {

	/** Iris's rule, and the one that decides most of our pages: three columns past this many. */
	private static final int WIDE_PAGE = 18;

	private static final MenuSlot BLANK = new MenuSlot.Blank();
	private static final MenuSlot PROFILES = new MenuSlot.Profiles();

	private final String packName;
	private final Map<String, MenuPage> pages;
	private final Map<String, MenuOption> options;
	private final Map<String, Map<String, String>> profiles;
	private final List<String> profileOrder;
	private final PackLang lang;
	private final List<String> warnings;

	private PackMenu(String packName, Map<String, MenuPage> pages, Map<String, MenuOption> options,
			Map<String, Map<String, String>> profiles, PackLang lang, List<String> warnings) {
		// Ordered rather than Map.copyOf: pages are walked in the order the pack writes them.
		this.packName = packName;
		this.pages = Collections.unmodifiableMap(new LinkedHashMap<>(pages));
		this.options = Collections.unmodifiableMap(new LinkedHashMap<>(options));
		this.profiles = Collections.unmodifiableMap(new LinkedHashMap<>(profiles));
		this.profileOrder = order(this.profiles);
		this.lang = lang;
		this.warnings = List.copyOf(warnings);
	}

	/**
	 * From the most constrained profile to the least, which is the order Iris both scans and cycles
	 * in: {@code Profile.java:21} makes a profile's precedence the number of settings it names and
	 * {@code ProfileSet.java:29} sorts on it, then {@code ProfileSet.java:101-102} takes the next and
	 * the previous from that sorted list rather than from the declared one.
	 * <p>
	 * The sort is stable, so a pack whose profiles all name the same count keeps the order it wrote
	 * them in, which is six of the eight in the corpus and BSL among them, BSL's five profiles all
	 * naming eight settings. Sildur's declares none. Body Camera is the one pack that moves: its
	 * three night vision profiles name twenty eight settings against the twenty five of the other
	 * three, so the cycle reaches them first here and last in the order the pack declares them.
	 * <p>
	 * Iris's own {@code ProfileSet.java:17} calls the declared order "the order that profiles should
	 * cycle through", and its code does not: only {@code forEach} reads that map.
	 */
	private static List<String> order(Map<String, Map<String, String>> profiles) {
		List<String> names = new ArrayList<>(profiles.keySet());
		names.sort(Comparator.comparingInt((String name) -> profiles.get(name).size()).reversed());

		return List.copyOf(names);
	}

	public static PackMenu build(String packName, OptionIndex index, ShaderProperties properties,
			PackLang lang) {
		Set<String> sliders = new HashSet<>(properties.sliders());
		Map<String, List<ShaderProperties.ScreenToken>> layout = properties.screenLayout();
		boolean hasProfiles = !properties.profiles().isEmpty();

		List<String> warnings = new ArrayList<>();
		Map<String, MenuOption> options = new LinkedHashMap<>();
		Map<String, List<MenuSlot>> slotsByPage = new LinkedHashMap<>();

		// Where each * sits. The dump happens after every page has claimed its names, because
		// the token means "everything no page shows", and what a later page shows is not known
		// while an earlier one is being walked.
		record Rest(List<MenuSlot> slots, int at) {
		}
		List<Rest> rests = new ArrayList<>();
		Set<String> subPlaced = new HashSet<>();

		for (Map.Entry<String, List<ShaderProperties.ScreenToken>> page : layout.entrySet()) {
			String where = page.getKey().isEmpty() ? "screen" : "screen." + page.getKey();
			List<MenuSlot> slots = new ArrayList<>();

			for (ShaderProperties.ScreenToken token : page.getValue()) {
				switch (token) {
					case ShaderProperties.ScreenToken.Blank _ -> slots.add(BLANK);
					case ShaderProperties.ScreenToken.Name(String name) -> {
						PackOption declared = index.get(name).orElse(null);
						if (declared == null) {
							warnings.add(where + " names " + name
									+ ", which the pack does not declare");
							slots.add(BLANK);
						} else if (!index.offers(declared)) {
							warnings.add(where + " names " + name
									+ ", declared but not a setting");
							slots.add(BLANK);
						} else {
							slots.add(new MenuSlot.Option(options.computeIfAbsent(name,
									_ -> MenuOption.of(declared, sliders.contains(name)))));
							if (!page.getKey().isEmpty()) {
								subPlaced.add(name);
							}
						}
					}
					case ShaderProperties.ScreenToken.Link(String target) -> {
						boolean resolved = layout.containsKey(target);
						if (!resolved) {
							warnings.add(where + " links to " + target
									+ ", which the pack does not lay out");
						}

						slots.add(new MenuSlot.Link(target, resolved));
					}
					// A pack with nothing to choose from loses the token rather than keeping a
					// blank where the selector would have been.
					case ShaderProperties.ScreenToken.Profiles _ -> {
						if (hasProfiles) {
							slots.add(PROFILES);
						}
					}
					case ShaderProperties.ScreenToken.Rest _ ->
							rests.add(new Rest(slots, slots.size()));
				}
			}

			slotsByPage.put(page.getKey(), slots);
		}

		// A pack that lays out no main screen means "everything", not "nothing": the reference
		// reads the missing line as a single *. That token goes first, ahead of any * a sub-page
		// carries, where the reference promises no winner at all, its dump walking a hash map.
		if (!slotsByPage.containsKey("")) {
			List<MenuSlot> main = new ArrayList<>();
			rests.add(0, new Rest(main, 0));
			slotsByPage.put("", main);
		}

		// The first * takes every offered setting no SUB-page names, in the order the pack
		// declares them, and a second one takes what remains, which by then is nothing. What the
		// main screen names pours out again on purpose: the reference fills its leftover list
		// only after its main screen is built, so those names dump twice there, and a pack that
		// laid its columns out against that must keep its shape here.
		if (!rests.isEmpty()) {
			List<MenuSlot> spill = new ArrayList<>();
			for (PackOption declared : index.all()) {
				if (subPlaced.contains(declared.name()) || !index.offers(declared)) {
					continue;
				}

				spill.add(new MenuSlot.Option(options.computeIfAbsent(declared.name(),
						_ -> MenuOption.of(declared, sliders.contains(declared.name())))));
			}

			rests.get(0).slots().addAll(rests.get(0).at(), spill);
		}

		Map<String, MenuPage> pages = new LinkedHashMap<>();
		slotsByPage.forEach((name, slots) -> pages.put(name, new MenuPage(name, slots,
				properties.columns(name).orElse(slots.size() > WIDE_PAGE ? 3 : 2))));

		Map<String, Map<String, String>> profiles = new LinkedHashMap<>();
		for (String name : properties.profiles().keySet()) {
			profiles.put(name, expand(properties, index, warnings, name));
		}

		return new PackMenu(packName, pages, options, profiles, lang, warnings);
	}

	/**
	 * What a profile constrains, which is not always what it writes.
	 * <p>
	 * A bare positive token naming a setting the pack declares nowhere is dropped, the one form the
	 * reference checks ({@code ProfileSet.java:78-81}), because a constraint on a name that exists
	 * nowhere can never be met and would cost the profile its whole purpose: Photon writes
	 * {@code GTAO} in all four of its profiles and declares it in none of its shaders, so keeping it
	 * makes every profile fail to match and the overlay read {@code Custom} on a pack nobody has
	 * touched.
	 */
	private static Map<String, String> expand(ShaderProperties properties, OptionIndex index,
			List<String> warnings, String name) {
		Map<String, String> expanded = new LinkedHashMap<>();
		properties.expandProfile(name, token -> {
			boolean toggle = index.get(token)
					.filter(option -> option.kind() == PackOption.Kind.TOGGLE)
					.isPresent();
			if (!toggle) {
				warnings.add("profile." + name + " names " + token
						+ ", which this pack declares nowhere as a toggle, so it is not a constraint");
			}

			return toggle;
		}).forEach((option, value) -> expanded.put(option, text(value)));

		return Collections.unmodifiableMap(expanded);
	}

	/**
	 * A boolean reads as {@code on} or {@code off} here rather than as {@code true} or
	 * {@code false}, because those are the two values a toggle offers and a value has to be
	 * comparable to what the widget cycles through.
	 */
	private static String text(OptionValue value) {
		if (value.isBoolean()) {
			return value.asBoolean() ? "on" : "off";
		}

		return value.text();
	}

	public String packName() {
		return this.packName;
	}

	public MenuPage main() {
		return this.pages.get("");
	}

	public Optional<MenuPage> page(String name) {
		return Optional.ofNullable(this.pages.get(name));
	}

	/** Every page including the main one, in the order the pack declares them. */
	public Collection<MenuPage> pages() {
		return this.pages.values();
	}

	public Optional<MenuOption> option(String name) {
		return Optional.ofNullable(this.options.get(name));
	}

	/** How many distinct settings the pages place, a setting named twice counting once. */
	public int optionCount() {
		return this.options.size();
	}

	/** Every setting the pages place, for a scan that has to visit each. */
	public Set<String> optionNames() {
		return this.options.keySet();
	}

	/** From the most constrained to the least, which is the order the selector walks through. */
	public List<String> profileNames() {
		return this.profileOrder;
	}

	/** One profile's settings, chain already resolved, as text. */
	public Map<String, String> profile(String name) {
		return this.profiles.getOrDefault(name, Map.of());
	}

	public PackLang lang() {
		return this.lang;
	}

	/** What did not resolve, one line each, for the log and for the harness. */
	public List<String> warnings() {
		return this.warnings;
	}
}
