package dev.vitrail.settings;

import dev.vitrail.pack.option.OptionValue;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * The order settings are resolved in, from the bottom: what the pack declares, then the profile
 * {@code vitrail/options.txt} forces, then the pack's own file, then that same file over
 * everything.
 * <p>
 * The last layer is deliberately last and deliberately global. It proves a pass runs, it applies to
 * whatever pack is loaded, and it is edited by hand while the game runs. What it holds is reported
 * so that the screen can grey those settings out instead of letting a click lose to them in silence.
 * <p>
 * Global is not the same as unconditional. Past the engine's own reserved lines, which this file
 * carries too and which {@code EngineOptions.RESERVED} names, a line of it forces a setting the
 * loaded pack <em>declares</em>; one naming neither keeps the pack's own defaults and is said so at
 * the load, by name. A settings name is an identifier, and defining a word the pack uses for
 * something of its own is how a whole pack comes to fail on a word nobody offered as a setting.
 * <p>
 * Only the top two layers are resolved here. The two below belong to the pack: a value nobody
 * chose is the one written in its source, and a profile is expanded by
 * {@code ShaderProperties.expandProfile} where the chain it may be part of can be followed.
 */
public final class SettingsLayers {

	/**
	 * The mod's own folder next to {@code mods/}. Spelled out rather than taken from
	 * {@code Vitrail.MOD_ID}, which lives in the class a loader initialises: this package is read
	 * by the out of game harness and one import of that class would end that.
	 */
	private static final String DIRECTORY = "vitrail";

	private static final String OPTIONS = "options.txt";

	private SettingsLayers() {
	}

	/** Named so that a caller can say in its log where a forced setting came from. */
	public static Path file(Path gameDirectory) {
		return gameDirectory.resolve(DIRECTORY).resolve(OPTIONS);
	}

	/**
	 * Reads {@code vitrail/options.txt}, one {@code NAME=value} per line, the reserved
	 * {@code profile} key included.
	 * <p>
	 * This file exists to make a pass provable. A pack's {@code final} is often nearly an identity
	 * with its settings at their defaults, which looks exactly like a pass that never ran; turning
	 * on one of the pack's own features settles it without touching the pack or writing a test
	 * shader that proves only itself. That is why it stays a file edited by hand, why it applies to
	 * whatever pack is loaded, and why it wins over the screen rather than the other way round.
	 * <p>
	 * One of the pack's own features, and that word carries the rule: a setting is applied by
	 * rewriting the line that declares it, so what this file can force of a pack is what the pack
	 * declares. Its other job is the reserved lines, which name this engine rather than a pack.
	 * Thirteen of those are read and taken out by {@code EngineOptions.take} and reach no pack at
	 * all; the fourteenth is {@code profile}, which is this layer's own and which {@link #resolve}
	 * takes out here to expand underneath the rest.
	 */
	public static Map<String, OptionValue> forced(Path gameDirectory) throws IOException {
		Path file = file(gameDirectory);
		if (!Files.isRegularFile(file)) {
			return Map.of();
		}

		Map<String, OptionValue> chosen = new LinkedHashMap<>();
		for (String line : text(file).lines().toList()) {
			String trimmed = line.trim();
			int equals = trimmed.indexOf('=');
			if (trimmed.isEmpty() || trimmed.startsWith("#") || equals < 1) {
				continue;
			}

			chosen.put(trimmed.substring(0, equals).trim(),
					OptionValue.parse(trimmed.substring(equals + 1).trim()));
		}

		return Collections.unmodifiableMap(chosen);
	}

	/**
	 * The file's text, decoded rather than refused.
	 * <p>
	 * Through the {@code String} constructor and not {@code Files.readAllLines}, which THROWS on a
	 * byte that is not UTF-8. This file is edited by hand, in whichever editor the player has, and
	 * that throw does not stop at the line it cannot read: it leaves {@code forced}, reaches
	 * {@code PackChoice.open}, and NO PACK LOADS AT ALL, under a message naming neither the file nor
	 * the encoding. What one stray byte costs instead is one character of one value.
	 * {@code SettingsFile.lines} reads its own file this way already, for the same reason.
	 * <p>
	 * A byte order mark is taken off rather than replaced, and that is the half nothing throws on.
	 * Left where it is it rides on the first key, so a first line naming {@code profile} declares a
	 * setting no pack has and no reserved line matches.
	 * <p>
	 * Cut by {@code lines} and not by a split on {@code \r?\n}, because {@code readAllLines} ends a
	 * line on a lone carriage return as well ({@code BufferedReader.readLine}) and a split on that
	 * pattern does not. A file saved with the old Mac endings would come back as ONE line, the
	 * first key swallowing every value after it in silence. {@code PackFile} reads its own file
	 * this way for the same reason.
	 */
	private static String text(Path file) throws IOException {
		String text = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);

		return text.startsWith("\uFEFF") ? text.substring(1) : text;
	}

	/**
	 * The user layer, the only one this side owns: the pack's file with the forced one on top.
	 * <p>
	 * A profile can only come from the forced file. A pack's own file holds the values a profile
	 * chooses rather than its name, which is how Iris writes it and what lets a file written here
	 * be read there.
	 */
	public static Resolved resolve(SettingsFile.Stored saved, Map<String, OptionValue> forced) {
		Map<String, OptionValue> chosen = new LinkedHashMap<>();
		saved.values().forEach((name, value) -> chosen.put(name, OptionValue.parse(value)));

		String profile = "";
		Set<String> forcedNames = new LinkedHashSet<>(forced.keySet());
		for (Map.Entry<String, OptionValue> entry : forced.entrySet()) {
			if (SettingsFile.PROFILE_KEY.equals(entry.getKey())) {
				profile = entry.getValue().asText();
			} else {
				chosen.put(entry.getKey(), entry.getValue());
			}
		}

		return new Resolved(Collections.unmodifiableMap(chosen), profile,
				Collections.unmodifiableSet(forcedNames));
	}

	/**
	 * Everything a pack is built with, once the layers underneath it have been folded together.
	 *
	 * @param chosen      everything a pack is built with, the reserved key taken out of it
	 * @param profile     the profile to expand underneath, "" for none
	 * @param forcedNames what {@code options.txt} holds, the reserved key included, so that a
	 *                    screen greys the profile selector out too when the file names a profile
	 */
	public record Resolved(Map<String, OptionValue> chosen, String profile,
			Set<String> forcedNames) {
	}
}
